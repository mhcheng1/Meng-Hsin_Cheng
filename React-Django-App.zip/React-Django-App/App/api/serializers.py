from rest_framework import serializers
from .models import Room

# Serializer defines the name of the field inside a Room
class RoomSerializer(serializers.ModelSerializer):
    class Meta:
        model = Room
        fields = ('id', 'code', 'host', 'isAlive', 'hint','answer', 'created_at')

# Only allows the given fields to be use as input when creating a new room
class CreateRoomSerializer(serializers.ModelSerializer):
    class Meta:
        model = Room
        fields = ('isAlive', 'hint', 'answer')
