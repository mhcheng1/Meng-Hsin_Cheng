from django.db import models
import string
import random


def generate_unique_code():
    length = 6
    # function called whenever a new room is needed
    while True:
        code = ''.join(random.choices(string.ascii_uppercase, k=length))
        if Room.objects.filter(code=code).count() == 0:
            break

    return code

# define the type of the fields inside a Room
class Room(models.Model):
    code = models.CharField(max_length=8, default=generate_unique_code, unique=True)
    isAlive = models.BooleanField(null=False, default=False)
    host = models.CharField(max_length=50, unique=True)
    hint = models.CharField(max_length=50, default='')
    answer = models.CharField(max_length=50, default='')
    created_at = models.DateTimeField(auto_now_add=True)
